<template>
    <div class="Hello"> Hello This is home page!</div>
</template>
<style scoped>
.Hello{
    font-size: 100px;
}
</style>