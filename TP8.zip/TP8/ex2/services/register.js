const register = (params) =>{
    // Read al users 

    // chek if the user existed

    // save to db

    // Return a complete user's info
    return "User's info"
}
module.exports = {
    register,
}